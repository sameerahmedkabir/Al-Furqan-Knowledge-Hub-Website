import { initializeApp } from "https://www.gstatic.com/firebasejs/10.7.1/firebase-app.js";
import { getAuth, createUserWithEmailAndPassword, signInWithEmailAndPassword, signOut } from "https://www.gstatic.com/firebasejs/10.7.1/firebase-auth.js";
import { getFirestore, collection, addDoc, query, where, getDocs } from "https://www.gstatic.com/firebasejs/10.7.1/firebase-firestore.js";

const firebaseConfig = {
  apiKey: "YOUR_API_KEY",
  authDomain: "YOUR_PROJECT.firebaseapp.com",
  projectId: "YOUR_PROJECT_ID",
};

const app = initializeApp(firebaseConfig);
const auth = getAuth(app);
const db = getFirestore(app);

window.register = async () => {
  await createUserWithEmailAndPassword(auth, email.value, password.value);
  alert("Registered");
};

window.login = async () => {
  const userCred = await signInWithEmailAndPassword(auth, email.value, password.value);
  dashboard.style.display = "block";
  userEmail.innerText = userCred.user.email;
};

window.logout = async () => {
  await signOut(auth);
  dashboard.style.display = "none";
};

window.enroll = async (course) => {
  alert("Enroll: " + course);
};

window.showAdmin = () => alert("Admin Panel");

window.payNow = () => alert("Payment Integration Here");

window.joinZoom = () => window.open("https://zoom.us");

window.scrollToTop = () => window.scrollTo({ top: 0, behavior: 'smooth' });
